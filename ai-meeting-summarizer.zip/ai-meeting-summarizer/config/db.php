<?php
// ============================================================
// AI Meeting Minutes Summarizer - Database Configuration
// ============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'ai_meeting_db');
define('DB_USER', 'root');
define('DB_PASS', '');

/**
 * Get PDO Database Connection
 * @return PDO|null
 */
function getDBConnection() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        // Return null so the API or page can offer demo/fallback mode if MySQL isn't running
        return null;
    }
}

/**
 * Return JSON Response Helper
 */
function sendJsonResponse($success, $data = [], $message = '', $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data'    => $data
    ]);
    exit;
}

// Start Session safely across pages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
